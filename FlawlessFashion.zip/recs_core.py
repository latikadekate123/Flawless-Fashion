"""
Recommendation System Core Module
Handles data loading, image embedding generation, and multimodal recommendations
"""
import pandas as pd
import numpy as np
import re
import unicodedata
import os
import io
import requests
from typing import Tuple, List, Optional
from pathlib import Path
import warnings
warnings.filterwarnings("ignore")

# ML imports
from scipy.sparse import hstack, csr_matrix
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import OneHotEncoder, MinMaxScaler
from sklearn.neighbors import NearestNeighbors
from functools import lru_cache

# Image/CLIP imports
import torch
from PIL import Image
import open_clip
from tqdm import tqdm


# Global variables for the recommender
df = None
X_content = None
nn_content = None
tfidf = None
ohe = None
image_embs = None
has_img = None
color_sets = None
price_scaled = None
brand_centroid = {}

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
MODEL_NAME = "ViT-B-32"
PRETRAIN = "laion2b_s34b_b79k"


def load_data(csv_path: str = "all_products_cleaned_master_8groups.csv") -> pd.DataFrame:
    """Load and preprocess the master dataset"""
    global df, color_sets, price_scaled
    
    df = pd.read_csv(csv_path)
    
    # Create dedupe key for avoiding near-duplicates
    def slug(s):
        s = "" if pd.isna(s) else str(s)
        s = unicodedata.normalize("NFKC", s).lower()
        s = re.sub(r"[^a-z0-9]+", " ", s).strip()
        return s
    
    df["dedupe_key"] = df["product_name"].map(slug) + "|" + df["brand"].map(slug)
    
    # Fill missing values
    for col in ["product_name", "brand", "category_group", "available_colors_cleaned", "price"]:
        if col not in df.columns:
            df[col] = np.nan
    
    df["product_name"] = df["product_name"].fillna("").astype(str)
    df["brand"] = df["brand"].fillna("Unknown").astype(str)
    df["category_group"] = df["category_group"].fillna("Other").astype(str)
    df["available_colors_cleaned"] = df["available_colors_cleaned"].fillna("").astype(str)
    
    # Parse price
    def parse_price(x):
        if pd.isna(x):
            return np.nan
        s = str(x)
        s = re.sub(r"[^\d\.]", "", s)
        try:
            return float(s) if s else np.nan
        except:
            return np.nan
    
    df["price_num"] = df["price"].apply(parse_price)
    
    # Preprocess colors as sets
    def colors_set(s):
        toks = re.split(r"[,\|/]+|\s{2,}", str(s))
        toks = [slug(t) for t in toks if slug(t)]
        return set(toks)
    
    color_sets = df["available_colors_cleaned"].apply(colors_set)
    
    # Scale prices
    scaler = MinMaxScaler()
    price_scaled = pd.Series(
        scaler.fit_transform(df[["price_num"]]).reshape(-1),
        index=df.index
    ).fillna(0.5)  # unknown prices get mid value
    
    print(f"Loaded {len(df)} products from {df['source_file'].nunique()} sources")
    return df


def build_content_vectors():
    """Build TF-IDF and one-hot encoded content vectors"""
    global X_content, nn_content, tfidf, ohe, brand_centroid
    
    def norm_text(s):
        if not isinstance(s, str):
            s = "" if pd.isna(s) else str(s)
        s = unicodedata.normalize("NFKC", s).lower()
        s = re.sub(r"[^a-z0-9]+", " ", s)
        return re.sub(r"\s+", " ", s).strip()
    
    # Build content text (product name + weighted brand + category)
    content_text = (
        df["product_name"].map(norm_text) + " " +
        df["brand"].map(lambda s: (norm_text(s) + " ") * 2) +  # brand gets 2x weight
        df["category_group"].map(lambda s: (norm_text(s) + " ") * 2)  # category gets 2x weight
    )
    
    # TF-IDF vectorization
    tfidf = TfidfVectorizer(ngram_range=(1, 2), min_df=2, max_features=40000)
    X_tfidf = tfidf.fit_transform(content_text)
    
    # One-hot encode brand and category
    ohe = OneHotEncoder(handle_unknown="ignore", sparse_output=True)
    X_ohe = ohe.fit_transform(df[["brand", "category_group"]])
    
    # Combine TF-IDF and one-hot features
    X_content = hstack([X_tfidf, X_ohe]).tocsr()
    
    # Build nearest neighbors index
    nn_content = NearestNeighbors(metric="cosine", algorithm="brute", n_jobs=-1)
    nn_content.fit(X_content)
    
    # Build brand centroids for similar brand recommendations
    brands = df["brand"].astype(str).values
    unique_brands = np.unique(brands)
    
    for b in unique_brands:
        idx = np.where(brands == b)[0]
        if len(idx) == 0:
            continue
        v = X_content[idx].mean(axis=0)
        v = np.asarray(v).ravel()  # Convert to 1-D array
        nrm = np.linalg.norm(v)
        if nrm > 0:
            v = v / nrm
        brand_centroid[b] = v
    
    print(f"Built content vectors: {X_content.shape}")


def load_image_from_url(url: str, timeout: int = 10, max_size: int = 512) -> Optional[Image.Image]:
    """Load and preprocess image from URL"""
    if not url or pd.isna(url):
        return None
    
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        response = requests.get(url, headers=headers, timeout=timeout, stream=True)
        response.raise_for_status()
        
        img = Image.open(io.BytesIO(response.content))
        if img.mode != "RGB":
            img = img.convert("RGB")
        
        # Resize if too large
        if max(img.size) > max_size:
            img.thumbnail((max_size, max_size), Image.Resampling.LANCZOS)
        
        return img
    except Exception:
        return None


def embed_images(images: List[Optional[Image.Image]], batch_size: int = 32) -> np.ndarray:
    """Generate CLIP embeddings for a list of images"""
    # Initialize CLIP model
    clip_model, _, clip_preprocess = open_clip.create_model_and_transforms(
        MODEL_NAME, pretrained=PRETRAIN, device=DEVICE
    )
    clip_model.eval()
    
    n = len(images)
    embeddings = np.full((n, 512), np.nan, dtype=np.float32)  # ViT-B-32 has 512-dim output
    
    with torch.no_grad():
        for i in tqdm(range(0, n, batch_size), desc="Embedding images"):
            batch_end = min(i + batch_size, n)
            batch_imgs = []
            valid_indices = []
            
            for j in range(i, batch_end):
                if images[j] is not None:
                    try:
                        batch_imgs.append(clip_preprocess(images[j]))
                        valid_indices.append(j)
                    except Exception:
                        continue
            
            if batch_imgs:
                batch_tensor = torch.stack(batch_imgs).to(DEVICE)
                batch_embs = clip_model.encode_image(batch_tensor)
                batch_embs = batch_embs / batch_embs.norm(dim=-1, keepdim=True)  # L2 normalize
                
                for idx, emb in zip(valid_indices, batch_embs.cpu().numpy()):
                    embeddings[idx] = emb
    
    return embeddings


def load_or_build_image_embs(cache_path: str = "image_embeddings_clip_vitb32.npy") -> np.ndarray:
    """Load cached image embeddings or build them from URLs"""
    global image_embs, has_img
    
    if os.path.exists(cache_path):
        image_embs = np.load(cache_path)
        print(f"Loaded cached image embeddings: {image_embs.shape}")
    else:
        print("Building image embeddings from URLs...")
        images = []
        for i, url in enumerate(tqdm(df["image_url"], desc="Loading images")):
            img = load_image_from_url(url) if isinstance(url, str) and url.strip() else None
            images.append(img)
        
        image_embs = embed_images(images, batch_size=32)
        np.save(cache_path, image_embs)
        print(f"Saved image embeddings: {image_embs.shape}")
    
    has_img = ~np.isnan(image_embs).any(axis=1)
    print(f"Valid image embeddings: {has_img.sum()}/{len(has_img)}")
    
    return image_embs


def similar_brands(base_brand: str, topk: int = 6) -> List[str]:
    """Find brands most similar to base brand in content space"""
    if base_brand not in brand_centroid:
        return [base_brand]
    
    base = brand_centroid[base_brand]
    sims = []
    for b, vec in brand_centroid.items():
        sim = float(np.dot(base, vec))
        sims.append((b, sim))
    
    sims.sort(key=lambda x: x[1], reverse=True)
    return [b for b, _ in sims[:topk]]


@lru_cache(maxsize=4096)
def _cached_pseudo_collab(i: int):
    """Cached pseudo-collaborative filtering scores"""
    return pseudo_collab_scores(i)


def pseudo_collab_scores(i: int) -> np.ndarray:
    """Compute pseudo-collaborative filtering scores for item i"""
    w_brand = 0.30
    w_cat = 0.35
    w_color = 0.20
    w_price = 0.15
    
    same_brand = (df["brand"].values == df.iloc[i]["brand"])
    same_cat = (df["category_group"].values == df.iloc[i]["category_group"])
    
    # Color Jaccard similarity
    A = color_sets.iloc[i]
    def jaccard(B):
        if not A and not B:
            return 0.0
        inter = len(A & B)
        union = len(A | B) if (A or B) else 1
        return inter / union
    
    color_sim = np.array([jaccard(s) for s in color_sets])
    
    # Price similarity
    pi = price_scaled.iloc[i]
    price_sim = 1.0 - np.abs(price_scaled.values - pi)
    
    # Combine
    scores = (w_brand * same_brand.astype(float) +
              w_cat * same_cat.astype(float) +
              w_color * color_sim +
              w_price * price_sim)
    
    # Normalize to [0, 1]
    scores = (scores - scores.min()) / (scores.max() - scores.min() + 1e-9)
    return scores


def image_sim_for_index(i: int, idxs: np.ndarray) -> np.ndarray:
    """Compute cosine similarity of image embeddings between item i and candidates"""
    if not has_img[i]:
        return np.zeros(len(idxs))
    
    base = image_embs[i] / np.linalg.norm(image_embs[i])
    
    # Handle cases where some candidates might not have images
    sims = np.zeros(len(idxs))
    for j, idx in enumerate(idxs):
        if has_img[idx]:
            candidate = image_embs[idx]
            candidate_norm = np.linalg.norm(candidate)
            if candidate_norm > 0:
                candidate = candidate / candidate_norm
                sims[j] = np.dot(base, candidate)
    
    return sims


def content_similarity_scores(i: int, k: int = 500) -> Tuple[np.ndarray, np.ndarray]:
    """Get content-based similarity scores"""
    dists, idxs = nn_content.kneighbors(X_content[i], n_neighbors=min(k + 1, X_content.shape[0]))
    idxs = idxs[0]
    dists = dists[0]
    content_scores = 1.0 - dists  # Convert distance to similarity
    return idxs, content_scores


def hybrid_scores_v2(i: int, k: int = 500, alpha: float = 0.6, beta: float = 0.2, gamma: float = 0.2) -> Tuple:
    """
    Compute hybrid recommendation scores combining content, collaborative, and image features
    
    Returns:
        idxs, hybrid_scores, content_sim, collab_sim, image_sim
    """
    # Get content neighbors
    idxs, content_scores = content_similarity_scores(i, k)
    
    # Map content scores to full array
    content_full = np.zeros(len(df))
    content_full[idxs] = content_scores
    
    # Get pseudo-collaborative scores for all items
    collab_full = _cached_pseudo_collab(int(i))
    
    # Get image similarities for the candidate items
    image_sim = image_sim_for_index(i, idxs)
    image_full = np.zeros(len(df))
    image_full[idxs] = image_sim
    
    # Combine with weights (normalize weights to sum to 1)
    total_weight = alpha + beta + gamma
    if total_weight > 0:
        alpha_norm = alpha / total_weight
        beta_norm = beta / total_weight
        gamma_norm = gamma / total_weight
    else:
        alpha_norm, beta_norm, gamma_norm = 0.33, 0.33, 0.34
    
    hybrid = (alpha_norm * content_full + 
              beta_norm * collab_full + 
              gamma_norm * image_full)
    
    # Remove self
    hybrid[i] = -1
    
    # Get top-k results
    top_idx = np.argpartition(-hybrid, range(min(k, len(df) - 1)))[:k]
    top_idx = top_idx[np.argsort(-hybrid[top_idx])]
    
    return top_idx, hybrid[top_idx], content_full[top_idx], collab_full[top_idx], image_full[top_idx]


def find_index_by_name(query: str) -> Optional[int]:
    """Find product index by fuzzy name matching"""
    def norm_text(s):
        s = "" if pd.isna(s) else str(s)
        s = unicodedata.normalize("NFKC", s).lower()
        s = re.sub(r"[^a-z0-9]+", " ", s)
        return re.sub(r"\s+", " ", s).strip()
    
    q = norm_text(query)
    hits = df.index[df["product_name"].map(lambda s: q in norm_text(s))]
    return int(hits[0]) if len(hits) else None


def recommend_mm(query, topn: int = 10, alpha: float = 0.6, beta: float = 0.2, gamma: float = 0.2,
                 same_brand: bool = False, same_category: bool = False, 
                 max_per_brand: int = 3, seed: int = None) -> pd.DataFrame:
    """
    Multimodal recommendation function
    
    Args:
        query: Product name (str) or index (int)
        topn: Number of recommendations
        alpha: Weight for content similarity
        beta: Weight for collaborative filtering  
        gamma: Weight for image similarity
        same_brand: Restrict to same brand
        same_category: Restrict to same category
        max_per_brand: Maximum items per brand
        seed: Random seed for reproducibility
    
    Returns:
        DataFrame with recommendations
    """
    # Find query item
    i = query if isinstance(query, int) else find_index_by_name(query)
    if i is None:
        print("No product matched your query.")
        return pd.DataFrame()
    
    # Get hybrid scores
    idxs, h, c, u, img = hybrid_scores_v2(i, k=max(topn * 50, 1000), 
                                          alpha=alpha, beta=beta, gamma=gamma)
    
    base_brand = df.iloc[i]["brand"]
    base_cat = df.iloc[i]["category_group"]
    query_key = df.iloc[i]["dedupe_key"]
    
    # Apply filters
    candidates = []
    seen_keys = {query_key}
    brand_counts = {}
    
    for j, score in zip(idxs, h):
        candidate_brand = df.iloc[j]["brand"]
        candidate_cat = df.iloc[j]["category_group"]
        candidate_key = df.iloc[j]["dedupe_key"]
        
        # Skip if already seen
        if candidate_key in seen_keys:
            continue
            
        # Apply brand/category filters
        if same_brand and candidate_brand != base_brand:
            continue
        if same_category and candidate_cat != base_cat:
            continue
            
        # Apply brand diversity constraint
        if brand_counts.get(candidate_brand, 0) >= max_per_brand:
            continue
            
        candidates.append(j)
        seen_keys.add(candidate_key)
        brand_counts[candidate_brand] = brand_counts.get(candidate_brand, 0) + 1
        
        if len(candidates) >= topn:
            break
    
    if not candidates:
        candidates = idxs[:topn]  # Fallback
    
    # Build result DataFrame
    result_cols = ["product_name", "brand", "category_group", "price", "image_url"]
    result = df.loc[candidates, result_cols].copy()
    
    # Add score columns
    score_map = dict(zip(idxs, h))
    content_map = dict(zip(idxs, c))
    collab_map = dict(zip(idxs, u))  
    image_map = dict(zip(idxs, img))
    
    result.insert(0, "hybrid_score", [round(score_map.get(j, 0), 4) for j in candidates])
    result.insert(1, "content_sim", [round(content_map.get(j, 0), 4) for j in candidates])
    result.insert(2, "collab_sim", [round(collab_map.get(j, 0), 4) for j in candidates])
    result.insert(3, "image_sim", [round(image_map.get(j, 0), 4) for j in candidates])
    
    return result.reset_index(drop=True)


def initialize_recommender(csv_path: str = "all_products_cleaned_master_8groups.csv", 
                          cache_path: str = "image_embeddings_clip_vitb32.npy"):
    """Initialize the complete recommendation system"""
    print("Loading data...")
    load_data(csv_path)
    
    print("Building content vectors...")
    build_content_vectors()
    
    print("Loading/building image embeddings...")
    load_or_build_image_embs(cache_path)
    
    print("✅ Recommendation system initialized!")
    return df
