# Fashion Recommendation System with Tinder-like UI

A multimodal AI-powered fashion recommendation system that combines text, collaborative filtering, and image similarity using CLIP (Contrastive Language-Image Pre-training) to provide personalized product suggestions through an intuitive swipe-based interface.

## Features

🤖 **Multimodal AI Recommendations**
- Text-based similarity using TF-IDF and product metadata
- Collaborative filtering based on brand, category, colors, and price
- Visual similarity using CLIP (ViT-B-32) image embeddings
- Configurable weight mixing: α·text + β·collab + γ·image

👆 **Tinder-like Swipe UI**
- One product card at a time with image, name, brand, price, category
- Like (👍) / Pass (👎) buttons with keyboard shortcuts (←/→)
- Real-time recommendation updates based on user preferences
- Session tracking with stats and history

🎛️ **Customizable Filters**
- Adjustable similarity weights (α, β, γ) with auto-normalization
- Brand and category filtering options  
- Brand diversity controls (max items per brand)
- Recommendation pool size configuration

⚡ **Performance Optimized**
- Cached image embeddings (saves to `.npy` file)
- Streamlit caching for data loading and models
- Batch image processing with progress indicators
- Efficient similarity computation with scikit-learn

## Dataset

The system works with the provided fashion dataset containing:
- **7,385 products** from 8 fashion brands
- **Categories**: Activewear, Swimwear, Dresses, Outerwear, Footwear, Casualwear, Innerwear, Accessories
- **Brands**: Alo Yoga, Altar'd State, Cupshe, Edikted, Gymshark, NA-KD, Princess Polly, Vuori

### Data Schema
Required columns in CSV:
- `product_name`: Product name/title
- `brand`: Brand name
- `category_group`: Product category
- `price`: Product price (will be parsed if needed)
- `image_url`: URL to product image
- `available_colors_cleaned`: Available colors (comma-separated)

## Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Run the App

```bash
streamlit run app.py
```

The app will:
1. Load the product dataset (`all_products_cleaned_master_8groups.csv`)
2. Build content vectors using TF-IDF and one-hot encoding
3. Download and embed product images using CLIP (first run only)
4. Launch the web interface at `http://localhost:8501`

### 3. Using the Interface

1. **Set Weights**: Adjust α (text), β (collaborative), γ (visual) in the sidebar
2. **Choose Query**: Search for a product or click "Random Product"  
3. **Swipe Products**: Use 👍/👎 buttons or ←/→ arrow keys
4. **Monitor Progress**: View liked/passed stats and recommendation scores

## Technical Architecture

### Core Components

**recs_core.py** - Main recommendation engine
- `load_data()`: Dataset loading and preprocessing
- `build_content_vectors()`: TF-IDF + one-hot encoding
- `load_or_build_image_embs()`: CLIP image embedding generation
- `hybrid_scores_v2()`: Multimodal similarity computation
- `recommend_mm()`: Main recommendation function

**app.py** - Streamlit web interface
- Product card display with images and metadata
- Interactive weight sliders with normalization  
- Session state management for likes/passes
- Real-time recommendation queue management

### Similarity Computation

**Text Similarity (α)**
- TF-IDF vectors on product_name + brand + category_group
- One-hot encoding for categorical features
- Cosine similarity using scikit-learn NearestNeighbors

**Collaborative Filtering (β)**
- Brand matching (30% weight)
- Category matching (35% weight)  
- Color overlap using Jaccard similarity (20% weight)
- Price proximity using scaled L1 distance (15% weight)

**Image Similarity (γ)**
- CLIP ViT-B-32 embeddings (512-dimensional)
- L2-normalized cosine similarity
- Batch processing with fallback for missing images

### Deduplication & Diversity

- **Dedupe Key**: `normalize(product_name) + "|" + normalize(brand)`
- **Brand Diversity**: Configurable max items per brand  
- **Similar Brands**: Content-space brand similarity for cross-brand recommendations
- **Fallback Logic**: Relaxes filters if recommendation pool too small

## Configuration

### Environment Variables
- `DEVICE`: Set to "cuda" for GPU acceleration (default: auto-detect)

### Model Configuration
```python
MODEL_NAME = "ViT-B-32"
PRETRAIN = "laion2b_s34b_b79k"  # 2B parameter CLIP model
```

### Recommendation Parameters
- `topn`: Number of recommendations (10-50)
- `alpha`: Text similarity weight (0.0-1.0, default: 0.6)
- `beta`: Collaborative weight (0.0-1.0, default: 0.2) 
- `gamma`: Image similarity weight (0.0-1.0, default: 0.2)
- `max_per_brand`: Brand diversity limit (1-10, default: 3)

## Performance Notes

### First Run
- Downloads CLIP model (~350MB) and processes all product images
- Image embedding generation takes ~10-30 minutes depending on hardware
- Embeddings cached in `image_embeddings_clip_vitb32.npy` for subsequent runs

### System Requirements
- **RAM**: 4GB+ (8GB+ recommended for full dataset)
- **GPU**: Optional but significantly speeds up image processing
- **Storage**: ~500MB for model cache and embeddings

### Optimization Tips
- Use GPU if available (`pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118`)
- Increase batch size for image processing on high-memory systems
- Pre-generate embeddings offline for production deployment

## Troubleshooting

### Common Issues

**"Import errors"** during development
- Install packages: `pip install -r requirements.txt`

**"CLIP model download fails"**  
- Check internet connection
- Try: `pip install --upgrade open_clip_torch`

**"Image loading timeouts"**
- Some product images may be unavailable
- System gracefully handles missing images with placeholders

**"Out of memory during embedding"**
- Reduce batch size in `embed_images()` function
- Close other applications to free RAM

### Debug Mode
Add to top of `app.py` for debugging:
```python
import logging
logging.basicConfig(level=logging.INFO)
st.set_option('deprecation.showPyplotGlobalUse', False)
```

## Extending the System

### Adding New Features
- **User Profiles**: Persist liked items across sessions
- **Advanced Filtering**: Size, material, price range filters
- **Recommendation Explanation**: Show why items were recommended
- **A/B Testing**: Compare different similarity algorithms

### Custom Datasets
To use your own fashion dataset:
1. Ensure CSV has required columns (see Data Schema above)
2. Update `csv_path` in `initialize_recommender()`
3. Adjust category mappings in `load_data()` if needed

### Alternative Models
- Replace CLIP with other vision models (ALIGN, BLIP, etc.)
- Experiment with different similarity metrics
- Add transformer-based text embeddings (BERT, RoBERTa)

## License & Credits

This project uses several open-source libraries:
- **OpenCLIP**: OpenAI CLIP implementation
- **Streamlit**: Web app framework  
- **scikit-learn**: Machine learning utilities
- **PyTorch**: Deep learning framework

Fashion dataset compiled from public retail websites for research purposes.

---

Built with ❤️ for fashion discovery and AI research.
