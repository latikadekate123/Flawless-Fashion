#!/bin/bash

echo "🚀 Fashion Recommendation System Launcher"
echo "=========================================="

# Check if virtual environment exists
if [ ! -d ".venv" ]; then
    echo "📦 Creating virtual environment..."
    python3 -m venv .venv
fi

# Activate virtual environment
echo "🔧 Activating virtual environment..."
source .venv/bin/activate

# Install/upgrade dependencies
echo "📚 Installing dependencies..."
pip install -q --upgrade pip
pip install -q -r requirements.txt

# Check if data file exists
if [ ! -f "all_products_cleaned_master_8groups.csv" ]; then
    echo "❌ Error: Dataset file 'all_products_cleaned_master_8groups.csv' not found!"
    echo "   Please ensure the dataset is in the current directory."
    exit 1
fi

echo "✅ Setup complete!"
echo ""
echo "🌐 Starting Streamlit app..."
echo "   Access the app at: http://localhost:8501"
echo "   Press Ctrl+C to stop the server"
echo ""

# Launch Streamlit app
streamlit run app.py --server.port 8501
