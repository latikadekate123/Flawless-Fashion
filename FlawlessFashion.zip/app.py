"""
Tinder-like Fashion Recommendation App
A swipe-based UI for discovering fashion products using multimodal AI
"""

import streamlit as st
import pandas as pd
import numpy as np
from pathlib import Path
import sys
import os

# Add current directory to path for imports
sys.path.append(str(Path(__file__).parent))

try:
    from recs_core import initialize_recommender, recommend_mm, df, find_index_by_name
except ImportError as e:
    st.error(f"Failed to import recommendation core: {e}")
    st.stop()

# Page config
st.set_page_config(
    page_title="Fashion Swipe Recs",
    page_icon="👗",
    layout="centered",
    initial_sidebar_state="expanded"
)

# Custom CSS for better UI
st.markdown("""
<style>
    .main-card {
        border: 2px solid #e6e6e6;
        border-radius: 15px;
        padding: 20px;
        margin: 20px 0;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        background: white;
    }
    
    .product-image {
        border-radius: 10px;
        max-width: 100%;
        height: auto;
    }
    
    .swipe-button {
        font-size: 2rem;
        border-radius: 50px;
        border: none;
        padding: 15px 30px;
        margin: 10px;
        cursor: pointer;
        transition: all 0.3s ease;
    }
    
    .like-button {
        background: linear-gradient(45deg, #ff6b6b, #ee5a24);
        color: white;
    }
    
    .pass-button {
        background: linear-gradient(45deg, #74b9ff, #0984e3);
        color: white;
    }
    
    .score-badge {
        display: inline-block;
        padding: 4px 8px;
        margin: 2px;
        border-radius: 15px;
        font-size: 0.8rem;
        background: #f8f9fa;
        color: #495057;
    }
    
    .stats-container {
        background: #f8f9fa;
        padding: 15px;
        border-radius: 10px;
        margin: 10px 0;
    }
</style>
""", unsafe_allow_html=True)

@st.cache_resource
def load_recommender():
    """Load the recommendation system (cached)"""
    try:
        return initialize_recommender()
    except Exception as e:
        st.error(f"Failed to initialize recommender: {e}")
        return None

@st.cache_data
def get_product_names():
    """Get list of product names for search (cached)"""
    if df is not None:
        return df["product_name"].dropna().tolist()
    return []

def normalize_weights(alpha, beta, gamma):
    """Normalize weights to sum to 1"""
    total = alpha + beta + gamma
    if total == 0:
        return 0.33, 0.33, 0.34
    return alpha/total, beta/total, gamma/total

def show_product_card(product_data, show_scores=True):
    """Display a product card with image and details"""
    col1, col2 = st.columns([1, 1])
    
    with col1:
        # Product image
        if pd.notna(product_data.get("image_url")) and product_data["image_url"]:
            try:
                st.image(
                    product_data["image_url"], 
                    caption=product_data.get("product_name", "Unknown Product"),
                    use_column_width=True
                )
            except Exception:
                st.image("https://via.placeholder.com/300x400?text=No+Image", 
                        caption="Image not available", use_column_width=True)
        else:
            st.image("https://via.placeholder.com/300x400?text=No+Image", 
                    caption="Image not available", use_column_width=True)
    
    with col2:
        # Product details
        st.markdown(f"### {product_data.get('product_name', 'Unknown Product')}")
        st.markdown(f"**Brand:** {product_data.get('brand', 'Unknown')}")
        st.markdown(f"**Category:** {product_data.get('category_group', 'Unknown')}")
        
        # Price
        price = product_data.get("price")
        if pd.notna(price):
            st.markdown(f"**Price:** ${price}")
        else:
            st.markdown("**Price:** Not available")
        
        # Show similarity scores if available and requested
        if show_scores and "hybrid_score" in product_data:
            st.markdown("**Similarity Scores:**")
            col_a, col_b = st.columns(2)
            with col_a:
                st.metric("Content", f"{product_data.get('content_sim', 0):.3f}")
                st.metric("Collaborative", f"{product_data.get('collab_sim', 0):.3f}")
            with col_b:
                st.metric("Image", f"{product_data.get('image_sim', 0):.3f}")
                st.metric("Hybrid", f"{product_data.get('hybrid_score', 0):.3f}")

def main():
    """Main Streamlit app"""
    
    # Title and description
    st.title("👗 Fashion Swipe Recommendations")
    st.markdown("Discover your next favorite fashion item with AI-powered recommendations!")
    
    # Initialize session state
    if "liked" not in st.session_state:
        st.session_state.liked = []
    if "passed" not in st.session_state:
        st.session_state.passed = []
    if "current_queue" not in st.session_state:
        st.session_state.current_queue = []
    if "query_item" not in st.session_state:
        st.session_state.query_item = "Airlift Intrigue Bra"
    if "initialized" not in st.session_state:
        st.session_state.initialized = False
    
    # Load recommender system
    if not st.session_state.initialized:
        with st.spinner("🤖 Loading AI recommendation system..."):
            recommender_df = load_recommender()
            if recommender_df is not None:
                st.session_state.initialized = True
                st.success("✅ Recommendation system loaded!")
            else:
                st.error("❌ Failed to load recommendation system")
                return
    
    # Sidebar controls
    with st.sidebar:
        st.header("🎛️ Recommendation Settings")
        
        # Weight controls
        st.subheader("Similarity Weights")
        alpha = st.slider("Text Content (α)", 0.0, 1.0, 0.6, 0.05, 
                         help="Weight for text-based similarity (product names, brands, categories)")
        beta = st.slider("Collaborative (β)", 0.0, 1.0, 0.2, 0.05,
                        help="Weight for collaborative filtering (brand, category, color, price)")  
        gamma = st.slider("Visual (γ)", 0.0, 1.0, 0.2, 0.05,
                         help="Weight for image similarity using AI vision")
        
        # Normalize weights
        alpha_norm, beta_norm, gamma_norm = normalize_weights(alpha, beta, gamma)
        st.caption(f"Normalized: α={alpha_norm:.2f}, β={beta_norm:.2f}, γ={gamma_norm:.2f}")
        
        st.subheader("Filtering Options")
        topn = st.slider("Recommendations Pool", 10, 50, 20, 5,
                        help="Number of candidate recommendations to generate")
        same_brand = st.checkbox("Same Brand Only", value=False)
        same_category = st.checkbox("Same Category Only", value=False)
        max_per_brand = st.slider("Max per Brand", 1, 10, 3, 1,
                                 help="Maximum items per brand in results")
        
        st.subheader("Query Selection")
        
        # Search by product name
        product_names = get_product_names()
        if product_names:
            query_input = st.text_input(
                "Search Product", 
                value=st.session_state.query_item,
                help="Type part of a product name to search"
            )
            
            # Show matching products
            if query_input:
                matches = [name for name in product_names if query_input.lower() in name.lower()]
                if matches:
                    selected_product = st.selectbox(
                        "Select Product", 
                        matches[:10],  # Show top 10 matches
                        help="Choose from matching products"
                    )
                    if st.button("🔄 New Query"):
                        st.session_state.query_item = selected_product
                        st.session_state.current_queue = []  # Clear queue
                        st.rerun()
        
        # Random product button
        if st.button("🎲 Random Product"):
            if df is not None:
                random_idx = np.random.randint(0, len(df))
                st.session_state.query_item = df.iloc[random_idx]["product_name"]
                st.session_state.current_queue = []
                st.rerun()
        
        # Stats
        st.subheader("📊 Session Stats")
        st.metric("👍 Liked", len(st.session_state.liked))
        st.metric("👎 Passed", len(st.session_state.passed))
        
        # Clear session
        if st.button("🗑️ Clear Session"):
            st.session_state.liked = []
            st.session_state.passed = []
            st.session_state.current_queue = []
            st.rerun()
    
    # Main content area
    if not st.session_state.initialized:
        st.info("Please wait while the recommendation system initializes...")
        return
    
    # Generate recommendations if queue is empty
    if not st.session_state.current_queue:
        with st.spinner("🔍 Finding recommendations..."):
            try:
                recommendations = recommend_mm(
                    query=st.session_state.query_item,
                    topn=topn,
                    alpha=alpha_norm,
                    beta=beta_norm, 
                    gamma=gamma_norm,
                    same_brand=same_brand,
                    same_category=same_category,
                    max_per_brand=max_per_brand
                )
                
                if len(recommendations) > 0:
                    # Convert to list of dicts for easier handling
                    st.session_state.current_queue = recommendations.to_dict('records')
                    st.success(f"Generated {len(st.session_state.current_queue)} recommendations!")
                else:
                    st.warning("No recommendations found. Try adjusting your settings.")
                    return
            except Exception as e:
                st.error(f"Error generating recommendations: {e}")
                return
    
    # Show current recommendation
    if st.session_state.current_queue:
        current_item = st.session_state.current_queue[0]
        
        st.markdown(f"### Recommendation {len(st.session_state.liked) + len(st.session_state.passed) + 1}")
        st.markdown(f"**Query:** {st.session_state.query_item}")
        
        # Display product card
        show_product_card(current_item, show_scores=True)
        
        # Swipe buttons
        col1, col2, col3 = st.columns([1, 2, 1])
        
        with col1:
            if st.button("👎 Pass", key="pass_btn", help="Not interested (Left Arrow)", use_container_width=True):
                handle_pass()
        
        with col3:
            if st.button("👍 Like", key="like_btn", help="I like this! (Right Arrow)", use_container_width=True):
                handle_like()
        
        # Keyboard shortcuts info
        st.caption("💡 Use ← → arrow keys for quick swiping!")
        
        # Progress indicator
        progress = (len(st.session_state.liked) + len(st.session_state.passed)) / (len(st.session_state.current_queue) + len(st.session_state.liked) + len(st.session_state.passed))
        st.progress(min(progress, 1.0))
        
    else:
        st.info("No more recommendations available. Try a new query or adjust your settings!")
        
        # Show liked items if any
        if st.session_state.liked:
            st.subheader("💖 Your Liked Items")
            for item in st.session_state.liked[-3:]:  # Show last 3 liked items
                with st.expander(f"❤️ {item.get('product_name', 'Unknown')}"):
                    show_product_card(item, show_scores=False)

def handle_like():
    """Handle like action"""
    if st.session_state.current_queue:
        current_item = st.session_state.current_queue.pop(0)
        st.session_state.liked.append(current_item)
        st.rerun()

def handle_pass():
    """Handle pass action"""  
    if st.session_state.current_queue:
        current_item = st.session_state.current_queue.pop(0)
        st.session_state.passed.append(current_item)
        st.rerun()

# Keyboard shortcuts using streamlit-keyup (if available)
try:
    from streamlit_keyup import st_keyup
    
    key = st_keyup("", key="keyup_component", debounce=100)
    if key == "ArrowRight":
        handle_like()
    elif key == "ArrowLeft":
        handle_pass()
except ImportError:
    # Fallback without keyboard shortcuts
    pass

if __name__ == "__main__":
    main()
