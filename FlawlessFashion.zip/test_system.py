"""
Quick test of the recommendation system
"""

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent))

from recs_core import initialize_recommender, recommend_mm

def main():
    print("🚀 Testing Fashion Recommendation System")
    print("=" * 50)
    
    try:
        # Initialize the system
        print("📋 Initializing recommender...")
        df = initialize_recommender()
        
        print(f"\n✅ System loaded with {len(df)} products")
        print(f"🏷️ Brands: {df['brand'].nunique()}")
        print(f"📦 Categories: {df['category_group'].value_counts().to_dict()}")
        
        # Test recommendations  
        print("\n🔍 Testing recommendations for 'Airlift Intrigue Bra'...")
        
        # Test different weight combinations
        test_cases = [
            {"alpha": 0.8, "beta": 0.1, "gamma": 0.1, "name": "Text-heavy"},
            {"alpha": 0.4, "beta": 0.4, "gamma": 0.2, "name": "Balanced"},
            {"alpha": 0.2, "beta": 0.2, "gamma": 0.6, "name": "Image-heavy"},
        ]
        
        for case in test_cases:
            print(f"\n📊 {case['name']} (α={case['alpha']}, β={case['beta']}, γ={case['gamma']}):")
            
            recs = recommend_mm(
                "Airlift Intrigue Bra",
                topn=5,
                alpha=case['alpha'],
                beta=case['beta'], 
                gamma=case['gamma'],
                max_per_brand=2
            )
            
            if len(recs) > 0:
                for i, row in recs.iterrows():
                    print(f"  {i+1}. {row['product_name']} | {row['brand']} | Score: {row['hybrid_score']:.3f}")
            else:
                print("  No recommendations found")
        
        print("\n✅ All tests passed! System ready for Streamlit app.")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
