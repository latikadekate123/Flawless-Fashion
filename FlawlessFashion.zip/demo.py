"""
Demonstration script showcasing the recommendation system features
"""

import sys
from pathlib import Path
sys.path.append(str(Path(__file__).parent))

from recs_core import initialize_recommender, recommend_mm, find_index_by_name
import recs_core

def demo_recommendations():
    """Demonstrate different recommendation scenarios"""
    print("🎯 FASHION RECOMMENDATION DEMO")
    print("=" * 60)
    
    # Initialize system
    print("🔧 Initializing system...")
    dataset = initialize_recommender()
    print(f"✅ Loaded {len(dataset)} products")
    
    print("\n" + "="*60)
    print("📋 DEMO 1: Different Weight Combinations")
    print("="*60)
    
    query = "Airlift Intrigue Bra"
    
    scenarios = [
        {
            "name": "🔤 TEXT-FOCUSED",
            "desc": "Emphasizes product names, brands, categories",
            "alpha": 0.8, "beta": 0.1, "gamma": 0.1
        },
        {
            "name": "🤝 COLLABORATIVE-FOCUSED", 
            "desc": "Emphasizes brand, category, color, price similarity",
            "alpha": 0.2, "beta": 0.7, "gamma": 0.1
        },
        {
            "name": "🖼️ IMAGE-FOCUSED",
            "desc": "Emphasizes visual similarity using AI",
            "alpha": 0.1, "beta": 0.1, "gamma": 0.8
        },
        {
            "name": "⚖️ BALANCED MULTIMODAL",
            "desc": "Even mix of all similarity types",
            "alpha": 0.4, "beta": 0.3, "gamma": 0.3
        }
    ]
    
    for scenario in scenarios:
        print(f"\n{scenario['name']}")
        print(f"Description: {scenario['desc']}")
        print(f"Weights: α={scenario['alpha']}, β={scenario['beta']}, γ={scenario['gamma']}")
        print("─" * 50)
        
        recs = recommend_mm(
            query, topn=5,
            alpha=scenario['alpha'],
            beta=scenario['beta'], 
            gamma=scenario['gamma'],
            max_per_brand=2
        )
        
        for i, (_, row) in enumerate(recs.iterrows(), 1):
            print(f"{i:2d}. {row['product_name'][:40]:<40} | {row['brand'][:12]:<12} | {row['category_group'][:10]:<10}")
            print(f"    💰${row['price']:<6} | 🎯{row['hybrid_score']:.3f} | 📝{row['content_sim']:.3f} | 🤝{row['collab_sim']:.3f} | 🖼️{row['image_sim']:.3f}")
    
    print("\n" + "="*60)
    print("📋 DEMO 2: Brand Diversity Control")
    print("="*60)
    
    diversity_tests = [
        {"max_per_brand": 1, "desc": "Maximum brand diversity"},
        {"max_per_brand": 3, "desc": "Moderate brand diversity"}, 
        {"max_per_brand": 10, "desc": "Allow brand clustering"}
    ]
    
    for test in diversity_tests:
        print(f"\n🔄 {test['desc']} (max {test['max_per_brand']} per brand)")
        print("─" * 40)
        
        recs = recommend_mm(
            query, topn=8,
            alpha=0.5, beta=0.3, gamma=0.2,
            max_per_brand=test['max_per_brand']
        )
        
        brand_counts = {}
        for i, (_, row) in enumerate(recs.iterrows(), 1):
            brand = row['brand']
            brand_counts[brand] = brand_counts.get(brand, 0) + 1
            print(f"{i:2d}. {row['product_name'][:35]:<35} | {brand[:15]:<15}")
        
        print(f"📊 Brand distribution: {dict(sorted(brand_counts.items()))}")
    
    print("\n" + "="*60)
    print("📋 DEMO 3: Cross-Category Recommendations")
    print("="*60)
    
    # Test different starting categories
    test_queries = [
        ("Bikini Set", "Swimwear → ?"),
        ("Airlift Intrigue Bra", "Activewear → ?"),
        ("Midi Dress", "Dresses → ?"),
        ("Puffer Jacket", "Outerwear → ?")
    ]
    
    for query_name, description in test_queries:
        idx = find_index_by_name(query_name)
        if idx is None:
            print(f"⚠️  Could not find '{query_name}', skipping...")
            continue
            
        query_item = recs_core.df.iloc[idx]
        print(f"\n🔍 {description}")
        print(f"Query: {query_item['product_name']} ({query_item['brand']} - {query_item['category_group']})")
        print("─" * 50)
        
        recs = recommend_mm(
            idx, topn=6,
            alpha=0.4, beta=0.4, gamma=0.2,
            same_category=False,  # Allow cross-category
            max_per_brand=2
        )
        
        category_counts = {}
        for i, (_, row) in enumerate(recs.iterrows(), 1):
            cat = row['category_group']
            category_counts[cat] = category_counts.get(cat, 0) + 1
            print(f"{i:2d}. {row['product_name'][:30]:<30} | {row['brand'][:10]:<10} | {cat}")
        
        print(f"📦 Category spread: {dict(sorted(category_counts.items()))}")
    
    print("\n" + "="*60)
    print("🎉 DEMO COMPLETE!")
    print("="*60)
    print("✅ All recommendation modes demonstrated successfully")
    print("🚀 Ready to launch Streamlit app: streamlit run app.py")
    print("🌐 The app provides an interactive Tinder-like interface")
    print("💡 Users can swipe through recommendations with real-time AI")


if __name__ == "__main__":
    demo_recommendations()
